
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'smaillns',
  applicationName: 'algiers-city-guide-api',
  appUid: 'vz3lF48zb2PlrjGkxX',
  orgUid: '3428e3a9-2f93-4be5-ab31-993accfe1d33',
  deploymentUid: '39f337c5-680a-4a4f-86d5-41d195823ae6',
  serviceName: 'algiers-city-guide-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'algiers-city-guide-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}