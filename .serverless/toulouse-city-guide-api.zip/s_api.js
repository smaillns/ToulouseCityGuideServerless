
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'smaillns',
  applicationName: 'toulouse-city-guide-api',
  appUid: 'JsL7SLCRJfCgXdjyLT',
  orgUid: '3428e3a9-2f93-4be5-ab31-993accfe1d33',
  deploymentUid: '944459f7-f86f-4a13-90d9-4b8eae621331',
  serviceName: 'toulouse-city-guide-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'toulouse-city-guide-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}